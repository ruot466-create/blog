(function () {
  'use strict';

  /* ============================================================
   * 学习清单 —— 数据 / 存储 / 视图三层
   *  - 数据层：纯函数，不碰 DOM，也不碰 localStorage（便于单独验证）
   *  - 存储层：读写 localStorage，全部包在 try/catch 里，失败就降级为内存状态
   *  - 视图层：根据 state.tasks 重新渲染列表与进度
   * ============================================================ */

  var STORAGE_KEY = 'learning-card:tasks';
  var LEGACY_KEY = 'learning-test:task-done';
  var SCHEMA_VERSION = 2;
  var MAX_TEXT_LENGTH = 80;
  var RESET_CONFIRM_MS = 3000;

  var DEFAULT_TASK_TEXTS = [
    '学习 JavaScript 30 分钟',
    '复习 CSS Flexbox 布局',
    '整理今天的学习笔记'
  ];

  /* ---------------- 数据层（纯函数） ---------------- */

  var idSeed = 0;

  function createId() {
    // 时间戳保证跨会话不重复，自增序号保证同一毫秒内多次调用也不重复。
    idSeed += 1;
    return 't' + Date.now().toString(36) + '-' + idSeed.toString(36);
  }

  function normalizeText(value) {
    if (typeof value !== 'string') {
      return '';
    }
    // 折叠连续空白 + 去首尾空格，再按上限截断，避免超长任务撑破布局。
    var text = value.replace(/\s+/g, ' ').trim();
    return text.length > MAX_TEXT_LENGTH ? text.slice(0, MAX_TEXT_LENGTH) : text;
  }

  // 把任意一条原始记录清洗成合法任务；无法修复时返回 null（由调用方丢弃）。
  function normalizeTask(raw) {
    if (!raw || typeof raw !== 'object') {
      return null;
    }
    var text = normalizeText(raw.text);
    if (!text) {
      return null;
    }
    return {
      id: typeof raw.id === 'string' && raw.id ? raw.id : createId(),
      text: text,
      done: raw.done === true,
      createdAt: typeof raw.createdAt === 'number' && isFinite(raw.createdAt)
        ? raw.createdAt
        : Date.now()
    };
  }

  function normalizeTasks(list) {
    if (!Array.isArray(list)) {
      return [];
    }
    var tasks = [];
    var seenId = {};
    for (var i = 0; i < list.length; i++) {
      var task = normalizeTask(list[i]);
      if (!task || seenId[task.id]) {
        continue; // 丢弃脏记录与重复 id，避免渲染出重复 key
      }
      seenId[task.id] = true;
      tasks.push(task);
    }
    return tasks;
  }

  // 解析存储内容：返回任务数组；无法解析时返回 null 交给上层回退到默认清单。
  // 注意：合法的空数组 [] 是有效状态，不能被当成“没有数据”。
  function parseStored(raw) {
    if (typeof raw !== 'string' || raw === '') {
      return null;
    }
    var parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (error) {
      return null;
    }
    if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.tasks)) {
      return null;
    }
    return normalizeTasks(parsed.tasks);
  }

  function serializeTasks(tasks) {
    return JSON.stringify({ version: SCHEMA_VERSION, tasks: tasks });
  }

  function createDefaultTasks() {
    var now = Date.now();
    return DEFAULT_TASK_TEXTS.map(function (text, index) {
      return { id: createId(), text: text, done: false, createdAt: now + index };
    });
  }

  function addTask(tasks, text) {
    var clean = normalizeText(text);
    if (!clean) {
      return tasks;
    }
    return tasks.concat([{ id: createId(), text: clean, done: false, createdAt: Date.now() }]);
  }

  function toggleTask(tasks, id, done) {
    return tasks.map(function (task) {
      if (task.id !== id) {
        return task;
      }
      return {
        id: task.id,
        text: task.text,
        done: typeof done === 'boolean' ? done : !task.done,
        createdAt: task.createdAt
      };
    });
  }

  function removeTask(tasks, id) {
    return tasks.filter(function (task) {
      return task.id !== id;
    });
  }

  function countDone(tasks) {
    return tasks.filter(function (task) {
      return task.done;
    }).length;
  }

  // 旧版本只存了单个任务的完成状态（字符串 'true'/'false'）。
  // 迁移规则：只有在没有 v2 数据时，才把这份状态套到默认清单的第一条上。
  function applyLegacyState(tasks, legacyValue) {
    if (legacyValue !== 'true' || tasks.length === 0 || tasks[0].done) {
      return tasks;
    }
    var migrated = tasks.slice();
    migrated[0] = {
      id: tasks[0].id,
      text: tasks[0].text,
      done: true,
      createdAt: tasks[0].createdAt
    };
    return migrated;
  }

  /* ---------------- 存储层 ---------------- */

  var storageBroken = false;

  function safeGetItem(key) {
    try {
      return window.localStorage.getItem(key);
    } catch (error) {
      storageBroken = true; // 隐私模式 / 被禁用：后续只走内存状态
      return null;
    }
  }

  function safeSetItem(key, value) {
    try {
      window.localStorage.setItem(key, value);
      return true;
    } catch (error) {
      storageBroken = true;
      return false;
    }
  }

  function safeRemoveItem(key) {
    try {
      window.localStorage.removeItem(key);
    } catch (error) {
      storageBroken = true;
    }
  }

  function readStoredTasks() {
    var raw = safeGetItem(STORAGE_KEY);
    var tasks = parseStored(raw);
    if (tasks) {
      return tasks;
    }
    if (typeof raw === 'string' && raw !== '') {
      // 数据损坏：不删除原始内容，但界面先回退到默认清单，用户下次操作会覆盖它。
      console.warn('[learning-card] 本地数据无法解析，已回退到默认清单');
    }

    var legacy = safeGetItem(LEGACY_KEY);
    var seeded = applyLegacyState(createDefaultTasks(), legacy);
    if (legacy !== null) {
      safeRemoveItem(LEGACY_KEY); // 迁移完成，旧键不再保留
    }
    return seeded;
  }

  function writeStoredTasks(tasks) {
    return safeSetItem(STORAGE_KEY, serializeTasks(tasks));
  }

  /* ---------------- 视图层 ---------------- */

  var els = {
    form: document.getElementById('task-form'),
    input: document.getElementById('task-input'),
    error: document.getElementById('task-error'),
    list: document.getElementById('task-list'),
    empty: document.getElementById('task-empty'),
    count: document.getElementById('progress-count'),
    track: document.getElementById('progress-track'),
    bar: document.getElementById('progress-bar'),
    reset: document.getElementById('reset-button')
  };

  var state = { tasks: [] };
  var resetTimer = null;

  function createTaskItem(task) {
    var item = document.createElement('li');
    item.className = task.done ? 'task task--done' : 'task';
    item.setAttribute('data-id', task.id);

    var label = document.createElement('label');
    label.className = 'task__label';

    var checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'task__checkbox';
    checkbox.checked = task.done;

    // 用 textContent 写入用户输入，天然不会有 HTML 注入问题
    var text = document.createElement('span');
    text.className = 'task__text';
    text.textContent = task.text;

    var status = document.createElement('span');
    status.className = 'task__status';
    status.textContent = task.done ? '已完成' : '未完成';

    var remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'task__delete';
    remove.textContent = '×';
    remove.title = '删除这条任务';
    remove.setAttribute('aria-label', '删除任务：' + task.text);

    label.appendChild(checkbox);
    label.appendChild(text);
    item.appendChild(label);
    item.appendChild(status);
    item.appendChild(remove);
    return item;
  }

  function renderList() {
    els.list.textContent = '';
    for (var i = 0; i < state.tasks.length; i++) {
      els.list.appendChild(createTaskItem(state.tasks[i]));
    }
    if (els.empty) {
      els.empty.hidden = state.tasks.length > 0;
    }
  }

  function renderProgress() {
    var total = state.tasks.length;
    var done = countDone(state.tasks);
    var percent = total === 0 ? 0 : Math.round((done / total) * 100);

    if (els.count) {
      els.count.textContent = done + ' / ' + total;
      els.count.classList.toggle('progress__count--all', total > 0 && done === total);
    }
    if (els.bar) {
      els.bar.style.width = percent + '%';
    }
    if (els.track) {
      els.track.setAttribute('aria-valuemin', '0');
      els.track.setAttribute('aria-valuemax', String(total));
      els.track.setAttribute('aria-valuenow', String(done));
      els.track.setAttribute('aria-valuetext', total === 0 ? '清单为空' : done + ' / ' + total + ' 已完成');
    }
  }

  function render() {
    renderList();
    renderProgress();
  }

  function showError(message) {
    if (!els.error) {
      return;
    }
    els.error.textContent = message;
    els.error.hidden = false;
    if (els.input) {
      els.input.setAttribute('aria-invalid', 'true');
    }
  }

  function clearError() {
    if (!els.error) {
      return;
    }
    els.error.textContent = '';
    els.error.hidden = true;
    if (els.input) {
      els.input.removeAttribute('aria-invalid');
    }
  }

  // 写入存储 + 重绘：所有会改变任务的入口都走这里，保证界面与存储一致
  function commit() {
    writeStoredTasks(state.tasks);
    render();
  }

  function disarmReset() {
    if (resetTimer !== null) {
      window.clearTimeout(resetTimer);
      resetTimer = null;
    }
    if (els.reset) {
      els.reset.textContent = '重置清单';
      els.reset.classList.remove('app__reset--armed');
    }
  }

  function handleSubmit(event) {
    event.preventDefault();
    var value = els.input ? els.input.value : '';
    if (!normalizeText(value)) {
      showError('任务内容不能为空');
      if (els.input) {
        els.input.focus();
      }
      return;
    }
    state.tasks = addTask(state.tasks, value);
    if (els.input) {
      els.input.value = '';
    }
    clearError();
    commit();
    if (els.input) {
      els.input.focus(); // 方便连续录入
    }
  }

  function handleListChange(event) {
    var target = event.target;
    if (!target || !target.classList || !target.classList.contains('task__checkbox')) {
      return;
    }
    var item = target.closest ? target.closest('.task') : null;
    var id = item && item.getAttribute('data-id');
    if (!id) {
      return;
    }
    state.tasks = toggleTask(state.tasks, id, target.checked);
    commit();
  }

  function handleListClick(event) {
    var target = event.target;
    var button = target && target.closest ? target.closest('.task__delete') : null;
    if (!button) {
      return;
    }
    var item = button.closest('.task');
    var id = item && item.getAttribute('data-id');
    if (!id) {
      return;
    }

    var items = els.list.querySelectorAll('.task');
    var index = 0;
    for (var i = 0; i < items.length; i++) {
      if (items[i].getAttribute('data-id') === id) {
        index = i;
        break;
      }
    }

    state.tasks = removeTask(state.tasks, id);
    commit();

    // 删除后把焦点交给后一条的删除按钮（没有就回到输入框），键盘操作不会丢焦点
    var buttons = els.list.querySelectorAll('.task__delete');
    var next = buttons.length > 0 ? buttons[Math.min(index, buttons.length - 1)] : null;
    if (next) {
      next.focus();
    } else if (els.input) {
      els.input.focus();
    }
  }

  function handleReset() {
    // 重置会丢掉用户自己的任务，所以做成两步点击，3 秒内没确认就自动取消
    if (!els.reset.classList.contains('app__reset--armed')) {
      disarmReset();
      els.reset.textContent = '确认重置？';
      els.reset.classList.add('app__reset--armed');
      resetTimer = window.setTimeout(disarmReset, RESET_CONFIRM_MS);
      return;
    }
    disarmReset();
    state.tasks = createDefaultTasks();
    commit();
  }

  function handleStorage(event) {
    // 同标签页不触发 storage 事件，这里处理的是“另一个标签页改了清单”的情况
    if (event.key !== null && event.key !== STORAGE_KEY && event.key !== LEGACY_KEY) {
      return;
    }
    state.tasks = readStoredTasks();
    render();
  }

  function init() {
    if (!els.form || !els.input || !els.list) {
      console.error('[learning-card] 页面缺少必要的容器元素，脚本未启动');
      return;
    }

    state.tasks = readStoredTasks();

    els.form.addEventListener('submit', handleSubmit);
    els.input.addEventListener('input', clearError);
    els.list.addEventListener('change', handleListChange);
    els.list.addEventListener('click', handleListClick);
    if (els.reset) {
      els.reset.addEventListener('click', handleReset);
    }
    window.addEventListener('storage', handleStorage);

    render();
  }

  init();
})();
